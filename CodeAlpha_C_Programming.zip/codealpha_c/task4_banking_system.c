/*
 * CodeAlpha C Programming Internship
 * Task 4: High – Banking System (Mini Project)
 * Author: Eugine Bhebhe
 * Student ID: CA/DF1/52319
 *
 * Description: A Bank Account Management System in C.
 *              Functions: Create Account, Deposit, Withdraw,
 *              Balance Enquiry, Transaction History, and Exit.
 *              Uses structures, functions, and file handling.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ACCOUNTS_FILE    "accounts.dat"
#define TRANSACTIONS_FILE "transactions.dat"
#define MAX_NAME  60
#define MAX_TRANS 10   /* transactions shown in history */

/* ── Structures ───────────────────────────────────────────── */
typedef struct {
    long   accountNumber;
    char   holderName[MAX_NAME];
    char   accountType[15];   /* Savings / Current */
    double balance;
    char   pin[5];            /* 4-digit PIN stored as string */
} Account;

typedef struct {
    long   accountNumber;
    char   type[15];          /* Deposit / Withdrawal */
    double amount;
    double balanceAfter;
    char   timestamp[30];
} Transaction;

/* ── Utility ──────────────────────────────────────────────── */
void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

void printBanner() {
    printf("\n╔══════════════════════════════════════════╗\n");
    printf("║      CODEALPHA BANK MANAGEMENT SYSTEM    ║\n");
    printf("║          Your Trusted Banking Partner    ║\n");
    printf("╚══════════════════════════════════════════╝\n");
}

void printDivider() {
    printf("------------------------------------------\n");
}

void getTimestamp(char *buf) {
    time_t t = time(NULL);
    struct tm *tm_info = localtime(&t);
    strftime(buf, 30, "%Y-%m-%d %H:%M:%S", tm_info);
}

long generateAccountNumber() {
    /* Base account number + count of existing accounts */
    FILE *fp = fopen(ACCOUNTS_FILE, "rb");
    if (!fp) return 1000000001L;

    Account a;
    long count = 0;
    while (fread(&a, sizeof(Account), 1, fp)) count++;
    fclose(fp);
    return 1000000001L + count;
}

/* ── Core file operations ─────────────────────────────────── */
int findAccount(long accNo, Account *out) {
    FILE *fp = fopen(ACCOUNTS_FILE, "rb");
    if (!fp) return 0;

    Account a;
    while (fread(&a, sizeof(Account), 1, fp)) {
        if (a.accountNumber == accNo) {
            *out = a;
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

int updateAccount(Account updated) {
    FILE *fp = fopen(ACCOUNTS_FILE, "r+b");
    if (!fp) return 0;

    Account a;
    while (fread(&a, sizeof(Account), 1, fp)) {
        if (a.accountNumber == updated.accountNumber) {
            fseek(fp, -(long)sizeof(Account), SEEK_CUR);
            fwrite(&updated, sizeof(Account), 1, fp);
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

void logTransaction(long accNo, const char *type, double amount, double balAfter) {
    Transaction t;
    t.accountNumber = accNo;
    strncpy(t.type, type, sizeof(t.type) - 1);
    t.amount       = amount;
    t.balanceAfter = balAfter;
    getTimestamp(t.timestamp);

    FILE *fp = fopen(TRANSACTIONS_FILE, "ab");
    if (fp) {
        fwrite(&t, sizeof(Transaction), 1, fp);
        fclose(fp);
    }
}

/* ── PIN verification ─────────────────────────────────────── */
int verifyPIN(Account *a) {
    char entered[10];
    printf("Enter 4-digit PIN: ");
    scanf("%4s", entered);
    clearInputBuffer();
    return strcmp(entered, a->pin) == 0;
}

/* ── Features ─────────────────────────────────────────────── */
void createAccount() {
    Account a;
    a.accountNumber = generateAccountNumber();

    printf("\n--- CREATE NEW ACCOUNT ---\n");
    printf("Account Number (auto): %ld\n", a.accountNumber);

    printf("Enter Full Name:       ");
    clearInputBuffer();
    fgets(a.holderName, MAX_NAME, stdin);
    a.holderName[strcspn(a.holderName, "\n")] = '\0';

    printf("Account Type:\n  1. Savings\n  2. Current\nChoice: ");
    int typeChoice;
    scanf("%d", &typeChoice);
    strcpy(a.accountType, (typeChoice == 2) ? "Current" : "Savings");

    printf("Initial Deposit (min R100): R");
    scanf("%lf", &a.balance);
    if (a.balance < 100) {
        printf("\n❌ Initial deposit must be at least R100. Account not created.\n");
        return;
    }

    printf("Set a 4-digit PIN: ");
    scanf("%4s", a.pin);
    clearInputBuffer();

    FILE *fp = fopen(ACCOUNTS_FILE, "ab");
    if (!fp) {
        printf("\nError: Could not save account!\n");
        return;
    }
    fwrite(&a, sizeof(Account), 1, fp);
    fclose(fp);

    logTransaction(a.accountNumber, "Deposit", a.balance, a.balance);

    printf("\n✅ Account created successfully!\n");
    printDivider();
    printf("  Account Number : %ld\n", a.accountNumber);
    printf("  Account Holder : %s\n",  a.holderName);
    printf("  Account Type   : %s\n",  a.accountType);
    printf("  Opening Balance: R%.2f\n", a.balance);
    printDivider();
    printf("  ⚠️  Please remember your Account Number and PIN.\n");
}

void depositMoney() {
    long accNo;
    Account a;

    printf("\n--- DEPOSIT ---\n");
    printf("Enter Account Number: ");
    scanf("%ld", &accNo);

    if (!findAccount(accNo, &a)) {
        printf("\n❌ Account not found.\n");
        return;
    }

    if (!verifyPIN(&a)) {
        printf("\n❌ Incorrect PIN. Access denied.\n");
        return;
    }

    double amount;
    printf("Enter deposit amount: R");
    scanf("%lf", &amount);

    if (amount <= 0) {
        printf("\n❌ Invalid amount.\n");
        return;
    }

    a.balance += amount;
    updateAccount(a);
    logTransaction(accNo, "Deposit", amount, a.balance);

    printf("\n✅ Deposit successful!\n");
    printf("  Deposited : R%.2f\n", amount);
    printf("  New Balance: R%.2f\n", a.balance);
}

void withdrawMoney() {
    long accNo;
    Account a;

    printf("\n--- WITHDRAWAL ---\n");
    printf("Enter Account Number: ");
    scanf("%ld", &accNo);

    if (!findAccount(accNo, &a)) {
        printf("\n❌ Account not found.\n");
        return;
    }

    if (!verifyPIN(&a)) {
        printf("\n❌ Incorrect PIN. Access denied.\n");
        return;
    }

    double amount;
    printf("Enter withdrawal amount: R");
    scanf("%lf", &amount);

    if (amount <= 0) {
        printf("\n❌ Invalid amount.\n");
        return;
    }

    if (amount > a.balance) {
        printf("\n❌ Insufficient funds! Available balance: R%.2f\n", a.balance);
        return;
    }

    /* Keep minimum R100 in savings */
    if (strcmp(a.accountType, "Savings") == 0 && (a.balance - amount) < 100) {
        printf("\n❌ Savings accounts must maintain a minimum balance of R100.\n");
        return;
    }

    a.balance -= amount;
    updateAccount(a);
    logTransaction(accNo, "Withdrawal", amount, a.balance);

    printf("\n✅ Withdrawal successful!\n");
    printf("  Withdrawn  : R%.2f\n", amount);
    printf("  New Balance: R%.2f\n", a.balance);
}

void balanceEnquiry() {
    long accNo;
    Account a;

    printf("\n--- BALANCE ENQUIRY ---\n");
    printf("Enter Account Number: ");
    scanf("%ld", &accNo);

    if (!findAccount(accNo, &a)) {
        printf("\n❌ Account not found.\n");
        return;
    }

    if (!verifyPIN(&a)) {
        printf("\n❌ Incorrect PIN. Access denied.\n");
        return;
    }

    printDivider();
    printf("  Account Number : %ld\n",  a.accountNumber);
    printf("  Account Holder : %s\n",   a.holderName);
    printf("  Account Type   : %s\n",   a.accountType);
    printf("  Current Balance: R%.2f\n", a.balance);
    printDivider();
}

void transactionHistory() {
    long accNo;
    Account a;

    printf("\n--- TRANSACTION HISTORY ---\n");
    printf("Enter Account Number: ");
    scanf("%ld", &accNo);

    if (!findAccount(accNo, &a)) {
        printf("\n❌ Account not found.\n");
        return;
    }

    if (!verifyPIN(&a)) {
        printf("\n❌ Incorrect PIN. Access denied.\n");
        return;
    }

    FILE *fp = fopen(TRANSACTIONS_FILE, "rb");
    if (!fp) {
        printf("\nNo transaction history found.\n");
        return;
    }

    /* Collect matching transactions */
    Transaction history[1000];
    int count = 0;
    Transaction t;
    while (fread(&t, sizeof(Transaction), 1, fp)) {
        if (t.accountNumber == accNo && count < 1000)
            history[count++] = t;
    }
    fclose(fp);

    if (count == 0) {
        printf("\nNo transactions found for this account.\n");
        return;
    }

    printf("\nLast %d transaction(s) for Account %ld:\n",
           (count < MAX_TRANS ? count : MAX_TRANS), accNo);
    printDivider();
    printf("  %-12s %-20s %-12s %s\n", "Type", "Timestamp", "Amount", "Balance After");
    printDivider();

    int start = (count > MAX_TRANS) ? count - MAX_TRANS : 0;
    for (int i = start; i < count; i++) {
        printf("  %-12s %-20s R%-11.2f R%.2f\n",
               history[i].type,
               history[i].timestamp,
               history[i].amount,
               history[i].balanceAfter);
    }
    printDivider();
}

/* ── Main ─────────────────────────────────────────────────── */
int main() {
    int choice;

    printBanner();

    while (1) {
        printf("\n--- MAIN MENU ---\n");
        printf("  1. Create Account\n");
        printf("  2. Deposit\n");
        printf("  3. Withdraw\n");
        printf("  4. Balance Enquiry\n");
        printf("  5. Transaction History\n");
        printf("  6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: createAccount();       break;
            case 2: depositMoney();        break;
            case 3: withdrawMoney();       break;
            case 4: balanceEnquiry();      break;
            case 5: transactionHistory();  break;
            case 6:
                printf("\n✅ Thank you for banking with CodeAlpha Bank. Goodbye!\n\n");
                return 0;
            default:
                printf("\nInvalid choice! Please try again.\n");
        }
    }

    return 0;
}
